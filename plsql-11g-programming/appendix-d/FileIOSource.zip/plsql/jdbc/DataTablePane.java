// --------------------------------------------------------------------
// DataTablePane.java
// Appendix D, Oracle Database 11g PL/SQL Programming
// by Michael McLaughlin
//
// This code demonstrates setting a JTabbedPane to enter query
// components.
// --------------------------------------------------------------------

// Define package structure.
package plsql.jdbc;

// Java Application class imports.
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;

// -----------------------------------------------------------------/
public class DataTablePane extends JTabbedPane {

  // Set constants.
  public static int TABLE_COLUMN_ALL = 1;
  public static int TABLE_AND_COLUMN = 2;
  public static int TABLE_COLUMN_KEY = 5;

  // Initialize components.
  private JTextArea queryTableName = new JTextArea();
  private JTextArea queryColumnName = new JTextArea();
  private JTextArea queryKeyColumnName = new JTextArea();
  private JTextArea queryKeyColumnValue = new JTextArea();
  private JTextArea operatingSystem = new JTextArea("WINDOWS");
  // -----------------------------------------------------------------/
  public DataTablePane() {
    setFont();
    setMessage(4);
    setTabLayoutPolicy(JTabbedPane.SCROLL_TAB_LAYOUT); }
  // -----------------------------------------------------------------/
  public DataTablePane(int tabs) {
    setFont();
    //if (tabs
    setMessage(tabs);
    setTabLayoutPolicy(JTabbedPane.SCROLL_TAB_LAYOUT); }
  // -----------------------------------------------------------------/
  public String getTableName() {
    return queryTableName.getText(); }
  // -----------------------------------------------------------------/
  public String getColumnName() {
    return queryColumnName.getText(); }
  // -----------------------------------------------------------------/
  public String getKeyColumnName() {
    return queryKeyColumnName.getText(); }
  // -----------------------------------------------------------------/
  public String getKeyColumnValue() {
    return queryKeyColumnValue.getText(); }
  // -----------------------------------------------------------------/
  public String getOperatingSystem() {
    return operatingSystem.getText(); }
  // -----------------------------------------------------------------/
  public void getTable() {
    System.out.println("Query Information:");
    System.out.println("=============================================");
    if (!getTableName().isEmpty())
      System.out.println("Table Name\t["+getTableName().toUpperCase()+"]");
    if (!getColumnName().isEmpty())
      System.out.println("Column Queried\t["+getColumnName().toUpperCase()+"]");
    if (!getKeyColumnName().isEmpty())
      System.out.println("Column Name\t["+getKeyColumnName().toUpperCase()+"]");
    if (!getKeyColumnValue().isEmpty())
      System.out.println("Column Value\t["+getKeyColumnValue().toUpperCase()+"]");
    if (!getOperatingSystem().isEmpty())
      System.out.println("OS Type Name\t["+getOperatingSystem().toUpperCase()+"]");
    System.out.println("============================================="); }
  // -----------------------------------------------------------------/
  private void setFont() {
    queryTableName.setFont(new Font(Font.SANS_SERIF,Font.PLAIN,14));
    queryColumnName.setFont(new Font(Font.SANS_SERIF,Font.PLAIN,14));
    queryKeyColumnName.setFont(new Font(Font.SANS_SERIF,Font.PLAIN,14));
    queryKeyColumnValue.setFont(new Font(Font.SANS_SERIF,Font.PLAIN,14));
    operatingSystem.setFont(new Font(Font.SANS_SERIF,Font.PLAIN,14)); }
  // -----------------------------------------------------------------/
  private void setMessage(int tabs) {
    setFont();

    // Set defaults to only meaning full even numbers.
    if (tabs > 2 && tabs < 4) tabs--;

    // Set ordering of tabs.
    for (int i = 0;i < tabs;i++)
      switch (i) {
        case 0:
          add("Table",queryTableName);
          break;
        case 1:
          add("Column",queryColumnName);
          break;
        case 2:
          add("Key Name",queryKeyColumnName);
          break;
        case 3:
          add("Key Value",queryKeyColumnValue);
          break; }

    // Set OS tab last by default.
    add("OS Name",operatingSystem);

    // Set pane size.
    setPreferredSize(new Dimension(350,50)); }}
