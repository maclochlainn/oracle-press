// --------------------------------------------------------------------
// DataConnectionPane.java
// Appendix D, Oracle Database 11g PL/SQL Programming
// by Michael McLaughlin
//
// This code demonstrates setting a JTabbedPane to enter and
// read the database connection components.
// --------------------------------------------------------------------

// Define package structure.
package plsql.jdbc;

// Java Application class imports.
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;

// -----------------------------------------------------------------/
public class DataConnectionPane extends JTabbedPane {

  // Initialize components.
  private JTextArea hostTA = new JTextArea();
  private JTextArea portTA = new JTextArea();
  private JTextArea dbnameTA = new JTextArea();
  private JTextArea useridTA = new JTextArea();
  private JTextArea passwdTA = new JTextArea();
  // -----------------------------------------------------------------/
  public DataConnectionPane() {
    setFont();
    setMessage();
    setTabLayoutPolicy(JTabbedPane.SCROLL_TAB_LAYOUT); }
  // -----------------------------------------------------------------/
  public String getHost() {
    return hostTA.getText(); }
  // -----------------------------------------------------------------/
  public String getPort() {
    return portTA.getText(); }
  // -----------------------------------------------------------------/
  public String getDatabase() {
    return dbnameTA.getText(); }
  // -----------------------------------------------------------------/
  public String getUserID() {
    return useridTA.getText(); }
  // -----------------------------------------------------------------/
  public String getPassword() {
    return passwdTA.getText(); }
  // -----------------------------------------------------------------/
  public void getConnection() {
    System.out.println("Connection Information:");
    System.out.println("=============================================");
    System.out.println("host\t["+hostTA.getText()+"]");
    System.out.println("port\t["+portTA.getText()+"]");
    System.out.println("dbname\t["+dbnameTA.getText()+"]");
    System.out.println("userid\t["+useridTA.getText()+"]");
    System.out.println("passwd\t["+passwdTA.getText()+"]");
    System.out.println("============================================="); }
  // -----------------------------------------------------------------/
  private void setFont() {
    hostTA.setFont(new Font(Font.SANS_SERIF,Font.PLAIN,14));
    portTA.setFont(new Font(Font.SANS_SERIF,Font.PLAIN,14));
    dbnameTA.setFont(new Font(Font.SANS_SERIF,Font.PLAIN,14));
    useridTA.setFont(new Font(Font.SANS_SERIF,Font.PLAIN,14));
    passwdTA.setFont(new Font(Font.SANS_SERIF,Font.PLAIN,14)); }
  // -----------------------------------------------------------------/
  private void setMessage() {
    setFont();
    add("Host",hostTA);
    add("Port",portTA);
    add("Database",dbnameTA);
    add("UserID",useridTA);
    add("Password",passwdTA);
    setPreferredSize(new Dimension(350,50)); }}
