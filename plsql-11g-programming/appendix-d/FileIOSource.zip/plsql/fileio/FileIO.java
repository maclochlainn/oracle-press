// --------------------------------------------------------------------
// FileIO.java
// Appendix D, Oracle Database 11g PL/SQL Programming
// by Michael McLaughlin
//
// This code demonstrates how to read files.
// --------------------------------------------------------------------

// Define package structure.
package plsql.fileio;

// Class imports.
import java.awt.Component;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.EOFException;
import java.io.IOException;
import java.io.File;
import java.io.FileReader;
import javax.imageio.ImageIO;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

// Supporting package files.
import plsql.fileio.FileTypeFilter;
import plsql.fileio.InvalidFileException;

// ---------------------------------------------------------------------------/
public abstract class FileIO {

  // Define constant primitive(s).
  private final static int ERROR       = JOptionPane.ERROR_MESSAGE;
  private final static int INFORMATION = JOptionPane.INFORMATION_MESSAGE;
  private final static int PLAIN       = JOptionPane.PLAIN_MESSAGE;
  private final static int QUESTION    = JOptionPane.QUESTION_MESSAGE;

  // Define primitive(s).
  private static boolean componentEnabled = false;

  // Define language wrapper class(es).
  private static String contents = new String();

  // Define Swing variable(s).
  private static Component caller;
  private static JFileChooser fileChooser;
  private static javax.swing.filechooser.FileFilter[] filter;

  // Define IO variable(s).
  private static BufferedReader input;
  private static File file;
  private static FileReader inFile;
  // -------------------------------------------------------------------------/
  public static File findFile(Component frame) {

    // Set environment.
    setComponent(frame);
    setFileChooser();
    setCurrentDirectory();

    // Invoke file chooser and return exit code.
    int result = fileChooser.showOpenDialog(frame);

    // Evaluate whether cancel button choosen and exit method.
    if (result == JFileChooser.CANCEL_OPTION)  { return null; }

    // Initialize variable with returned file.
    file = fileChooser.getSelectedFile();

    // Return file.
    return file; }
  // -------------------------------------------------------------------------/
  public static File nameFile(Component frame) {

    // Set environment.
    setComponent(frame);
    setFileChooser();
    setCurrentDirectory();

    // Invoke file chooser and return exit code.
    int result = fileChooser.showSaveDialog(frame);

    // Evaluate whether cancel button choosen and exit method.
    if (result == JFileChooser.CANCEL_OPTION)  { return null; }

    // Initialize variable with returned file.
    file = fileChooser.getSelectedFile();

    // Return file.
    return file; }
  // -------------------------------------------------------------------------/
  public static String openFile(File file) {
    return openFile(null,file); }
  // -------------------------------------------------------------------------/
  public static String openFile(Component frame,File file)
  {
    // Initialize Component when not null for modality.
    setComponent(frame);

    // Define and initialize local Swing variable(s).
    String retValue = new String("");

    // Raise an error if file name is null or open file.
    if (file == null || file.getName().equals("")) {

      // If modal Component enabled.
      if (!componentEnabled) {
        // Throw runtime exception for a null file reference.
        throw new InvalidFileException("File reference is a null value."); }}
    else {

      // Open file for sequential read.
      try {

        // Create a BufferedReader for line-by-line read.
        input = new BufferedReader(new FileReader(file));

        // Read file line-by-line to end-of-file marker.
        readFile();

        // Assign read contents.
        retValue = contents;

        // Close file because static context disallows maintaining it.
        input.close(); }
      catch (IOException e) {

        // If modal Component enabled.
        if (componentEnabled) {

          // Display message dialog.
          showMessageDialog("File name or path not found.",
                            "File IO error",ERROR); }
        else {
          // Throw runtime exception for a bad file name or path.
          throw new InvalidFileException("File name or path not found."); }}}

    // Return value.
    return retValue; }
  // -----------------------------------------------------------------/
  private static String readEntry() {
    try {

      // Define method variables.
      int c;
      StringBuffer buffer = new StringBuffer();

      // Read first character.
      c = System.in.read();

      // Read remaining characters.
      while (c != '\n' && c != -1) {
        buffer.append((char) c);
        c = System.in.read(); }

      // Return buffer.
      return buffer.toString().trim(); }
    catch (IOException e) {
      return null; }}
  // -------------------------------------------------------------------------/
  private static void readFile() {

    // Define String(s).
    String line = new String();

    // Try to read the file.
    try
    {
      // Read initial line into String variable.
      line = input.readLine();

      // Assign line to file String.
      contents = line + "\n";

      // Read file until no new lines.
      while (line != null) {
        line = input.readLine();

        // Concatenate the line to the file.
        if (line != null)
          { contents += line + "\n"; }}}
    catch ( EOFException eofe) {

      // Display message dialog.
      showMessageDialog("No more lines to read.",
                        "End of file error",ERROR); }
    catch ( IOException ioe) {

      // Display message dialog.
      showMessageDialog("Error reading file.",
                        "File IO error",ERROR); }}
  // -------------------------------------------------------------------------/
  private static void setComponent(Component frame) {

    // If Component is not null then initialize it for modality.
    if (frame != null)
    {
      // Initialize calling Component.
      caller = frame;

      // Enable component flag.
      componentEnabled = true; }}
  // -------------------------------------------------------------------------/
  private static void setCurrentDirectory() {

    // Evaluate OS type, MS Windows or UNIX.
    if (new Character(File.separatorChar).charValue() == '\\') {
      file = new File("C:\\"); }
    else {
      file = new File("/"); }

    // Initialize JFileChooser states.
    fileChooser.setCurrentDirectory(file); }
  // -------------------------------------------------------------------------/
  private static void setFileChooser() {

    // Initialize FileChooser
    fileChooser = new JFileChooser();

    // Initialize FileFilter.
    javax.swing.filechooser.FileFilter[] filter =
      new javax.swing.filechooser.FileFilter[]
      { new FileTypeFilter("C/C++",
          new String[] { "c","cpp","h","hpp","cxx","hxx","inl" }),
        new FileTypeFilter("HTML",
          new String[] { "htm","html","stm" }),
        new FileTypeFilter("Image",
          new String[] { "gif","jpg","png" }),
        new FileTypeFilter("Java",
          new String[] { "java","sqlj" }),
        new FileTypeFilter("Log",
          new String[] { "log","lst" }),
        new FileTypeFilter("Oracle",
          new String[] { "pls","pll","ora","sql" }),
        new FileTypeFilter("Text",
          new String[] { "cfg","ini","txt" })
      };

    // Loop to populate the JFileChooser with a FileFilter.
    for (int i = 0;i < filter.length;i++)
    {
      // Assign a FileFilter to the JFileChooser.
      fileChooser.addChoosableFileFilter(filter[i]); }

    // Set JFileChooser FileFilter with all FileFilter values.
    fileChooser.setFileFilter(fileChooser.getAcceptAllFileFilter()); }
  // -------------------------------------------------------------------------/
  private static void showMessageDialog(String msg,String title,int msgType) {

    // Display message dialog.
    JOptionPane.showMessageDialog(caller,msg,title,msgType);

    // Signal an explict exception error to release resources on Windows.
    System.exit(0); }}
  // -------------------------------------------------------------------------/
